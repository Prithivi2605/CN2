import socket
import binascii  # For real CRC

# Create TCP socket
client = socket.socket()
client.connect(('localhost', 12345))

# Get message from user
message = input("Enter message: ")

# Calculate CRC of message
crc = binascii.crc32(message.encode())

# Send message with CRC
packet = f"{message}|{crc}"
client.send(packet.encode())

client.close()

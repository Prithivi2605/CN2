import socket
import binascii  # For real CRC calculation

# Create TCP socket
server = socket.socket()
server.bind(('localhost', 12345))
server.listen(1)

print("Server waiting for connection...")
conn, addr = server.accept()
print("Connected to", addr)

# Receive message
data = conn.recv(1024).decode()
message, crc_received = data.split('|')
crc_received = int(crc_received)

# Calculate CRC on received message
crc_calculated = binascii.crc32(message.encode())

# Compare and print result
if crc_received == crc_calculated:
    print("✅ Message OK:", message)
else:
    print("❌ CRC Error: Message corrupted")

conn.close()

import socket
import binascii

# Create UDP socket
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind(('localhost', 12345))
print("UDP server ready...")

# Receive data
data, addr = server.recvfrom(1024)
message, crc_received = data.decode().split('|')
crc_received = int(crc_received)

# Calculate and compare CRC
crc_calculated = binascii.crc32(message.encode())

if crc_received == crc_calculated:
    print("✅ Message OK:", message)
else:
    print("❌ CRC Error")

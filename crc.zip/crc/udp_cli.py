import socket
import binascii

# Create UDP socket
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Get message from user
message = input("Enter message: ")

# Calculate CRC
crc = binascii.crc32(message.encode())

# Send message and CRC together
packet = f"{message}|{crc}"
client.sendto(packet.encode(), ('localhost', 12345))

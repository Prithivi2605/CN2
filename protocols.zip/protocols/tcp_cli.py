import socket

c = socket.socket()
c.connect(('localhost', 12347))

print(c.recv(1024).decode())
while True:
    msg = input("TCP > ")
    c.send(msg.encode())
    if msg.strip().lower() == "exit":
        break
    print("Server >", c.recv(4096).decode())

c.close()
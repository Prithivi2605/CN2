import socket

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server = ('localhost', 12348)

print("UDP Client. Use commands like 'ftp test.txt', 'arp 192.168.1.2', 'exit'")
while True:
    msg = input("UDP > ")
    s.sendto(msg.encode(), server)
    if msg.strip().lower() == "exit":
        break
    response, _ = s.recvfrom(4096)
    print("Server >", response.decode())

s.close()
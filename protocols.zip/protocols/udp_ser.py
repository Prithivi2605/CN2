import socket
from protocols import process_protocol_command

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(('localhost', 12348))
print("UDP protocol server started.")

while True:
    data, addr = s.recvfrom(1024)
    msg = data.decode()
    if msg.strip().lower() == "exit":
        break
    response = process_protocol_command(msg)
    s.sendto(response.encode(), addr)
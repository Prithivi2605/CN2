import socket
from protocols import process_protocol_command

s = socket.socket()
s.bind(('localhost', 12347))
s.listen(1)
print("TCP protocol server started.")
conn, addr = s.accept()
print(f"Client connected: {addr}")

conn.send("Welcome to Protocol Server. Use commands like 'ftp file.txt', 'arp 192.168.1.2', 'exit'\n".encode())

while True:
    data = conn.recv(1024).decode()
    if not data or data.strip().lower() == "exit":
        break
    response = process_protocol_command(data)
    conn.send(response.encode())

conn.close()
s.close()
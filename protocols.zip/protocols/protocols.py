import socket

arp_table = {
    "192.168.1.2": "AA:BB:CC:DD:EE:01",
    "192.168.1.3": "AA:BB:CC:DD:EE:02"
}

rarp_table = {
    "AA:BB:CC:DD:EE:01": "192.168.1.2",
    "AA:BB:CC:DD:EE:02": "192.168.1.3"
}

def ftp_simulate(filename):
    try:
        with open(filename, 'r') as f:
            return f.read()
    except FileNotFoundError:
        return "File not found"

def arp(ip):
    return arp_table.get(ip, "MAC not found")

def rarp(mac):
    return rarp_table.get(mac, "IP not found")

def dns(domain):
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return "DNS resolution failed"

def http(host):
    try:
        s = socket.socket()
        s.connect((host, 80))
        s.sendall(f"GET / HTTP/1.1\r\nHost: {host}\r\n\r\n".encode())
        response = s.recv(2048).decode()
        s.close()
        return response
    except Exception as e:
        return f"HTTP error: {e}"

def sliding_window(data, size):
    chunks = [data[i:i+size] for i in range(0, len(data), size)]
    return "\n".join(f"Window: {chunk}" for chunk in chunks)

def go_back_n(data, size):
    result = []
    i = 0
    while i < len(data):
        result.append(f"Sending: {data[i:i+size]}")
        result.append("ACK not received. Resending...")
        i += size
    return "\n".join(result)

def selective_repeat(data, size):
    result = []
    for i in range(0, len(data), size):
        chunk = data[i:i+size]
        result.append(f"Sending: {chunk}")
        result.append("ACK received.")
    return "\n".join(result)

def process_protocol_command(cmd):
    try:
        parts = cmd.strip().split()
        op = parts[0].lower()

        if op == "ftp":
            return ftp_simulate(parts[1])
        elif op == "arp":
            return arp(parts[1])
        elif op == "rarp":
            return rarp(parts[1])
        elif op == "dns":
            return dns(parts[1])
        elif op == "http":
            return http(parts[1])
        elif op == "sw":
            return sliding_window(parts[1], int(parts[2]))
        elif op == "gbn":
            return go_back_n(parts[1], int(parts[2]))
        elif op == "sr":
            return selective_repeat(parts[1], int(parts[2]))
        else:
            return "Unknown protocol command"
    except Exception as e:
        return f"Error: {e}"